package assignment1;

public class Employee {
public void working() {
	System.out.println("I do the work");
}
}
