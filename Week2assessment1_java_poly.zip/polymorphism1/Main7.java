package assignment1;

public class Main7 {
public static void main(String[] args) {
	Manager m = new Manager();
	m.working();
}
}
