package assignment1;

public class Manager extends Employee{
public void working() {
	System.out.println("Manage the team dear Employee");
}
}
