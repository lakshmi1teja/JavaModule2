package assignment1;

public class WashingMachine {
public void turnOn() {
	System.out.println("Automatically turn on when closes door");
}
}
