package assignment1;

public class Main8 {
public static void main(String[] args) {
	WashingMachine wm= new WashingMachine();
	wm.turnOn();
}
}
