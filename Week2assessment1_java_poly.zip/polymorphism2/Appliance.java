package assignment1;

public class Appliance {
public void turnOn() {
	System.out.println("Plug it to switch on");
}
}
