package assignment1;

import java.util.Scanner;

public class Main5 {

	public static void main(String[] args) {
	

		Car myCar = new Car("Toyota", "Camry", 50);

		myCar.accelerate(50);
		myCar.brake(20);
		myCar.openSunRoof();
		myCar.playMusic("Levitating");
	}

}
