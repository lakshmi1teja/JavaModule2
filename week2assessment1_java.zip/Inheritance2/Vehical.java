package assignment1;

public class Vehical {
//make, model, speed
	String make;
	String model;
	double speed;

public Vehical(String make, String model, double speed) {
	this.make = make;
	this.model=model;
	this.speed=speed;
}

	public void accelerate(double acc) {
		speed+=acc;
		System.out.println("When accelerator pressed speed is: "+speed);
	}
	public void brake(double dec) {
		speed-=dec;
		if(speed<0) {
			System.out.println(speed);
		}
		System.out.println("Speed after hitting brake: "+speed);
	}
}
class Car extends Vehical{

Car(String make, String model, double speed) {
super(make, model, speed);
}

	public void openSunRoof() {
		System.out.println("It's an open sunroof!");
	}
	public void playMusic(String song) {
		System.out.println("Playin song name: "+song);
	}
}
