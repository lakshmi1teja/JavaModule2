package assignment1;

public class Animal {
	String animalType;
	Animal(String animalType){
		this.animalType=animalType;
	}
public void eat() {
	System.out.println(animalType+" can eat");
}
public void sleep() {
	System.out.println(animalType+" can sleep");
}
}
