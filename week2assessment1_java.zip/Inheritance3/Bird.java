package assignment1;

public class Bird extends Animal{

	Bird(String animalType){
		super(animalType);
	}
	public void fly() {
		System.out.println(animalType+" can fly");
	}

}
