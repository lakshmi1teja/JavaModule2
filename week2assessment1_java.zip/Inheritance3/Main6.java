package assignment1;

import java.util.Scanner;

public class Main6 {

	public static void main(String[] args) {
		Scanner c = new Scanner(System.in);
		String bname = c.nextLine();
		Bird b = new Bird("Bird");
		String pname = c.nextLine();
		Parrot p = new Parrot("Parrot");
		b.eat();
		b.sleep();
		b.fly();
		p.talk();
		p.mimic();
	}

}
