package assignment1;

public class Parrot extends Bird{
	Parrot(String animalType){
		super(animalType);
	}
	public void talk() {
		System.out.println(animalType+" can talk");
	}
	public void mimic() {
		System.out.println(animalType+" can mimic");
	}
}
