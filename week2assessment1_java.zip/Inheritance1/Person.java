package assignment1;

class Person {
	//name, age, and address
	String name;
	int age;
	String address;
	public void displayInfo(String nm,int ag,String add) {
		name=nm;
		age=ag;
		address=add;
		System.out.println(nm+" "+" "+ag+" "+add);
	}
}
class Student extends Person{
	//studentId, grade
	int studentId;
	char grade;
	String major;
	public void study(int stuId,char grd,String maj) {
		studentId=stuId;
		grade=grd;
		major=maj;
		System.out.println(stuId+" "+grd+" "+" "+maj);
	}
}
