package assignment1;

import java.util.Scanner;

public class Main4 {
    public static void main(String[] args) {
        Student s = new Student();
        Scanner sc = new Scanner(System.in);
        
        // Person info
        System.out.println("Enter name of person:");
        String nam = sc.nextLine();
        System.out.println("Enter the age of the person:");
        int years = sc.nextInt();
        sc.nextLine(); // Consume the newline character
        System.out.println("Enter the address:");
        String ad = sc.nextLine();
        
        // Student info
        System.out.println("Enter the student Id:");
        int sId = sc.nextInt();
        sc.nextLine(); // Consume the newline character
        System.out.println("Enter the grade:");
        char gra = sc.next().charAt(0);
        sc.nextLine(); // Consume the newline character
        System.out.println("Enter the major:");
        String majo = sc.nextLine();
        
        //System.out.println(nam + ", " + years + ", " + ad);
        s.displayInfo(nam, years, ad);
        
        //System.out.println(sId + ", " + gra + ", " + majo);
        s.study(sId, gra, majo);
    }
}
